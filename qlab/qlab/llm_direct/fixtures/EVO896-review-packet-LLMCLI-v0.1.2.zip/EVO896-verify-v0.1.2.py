"""Offline artifact integrity/scope checks. No model, market, strategy or DSR execution."""
from pathlib import Path
import copy
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
checks = []

def digest(b): return hashlib.sha256(b).hexdigest()
def raw(name): return (ROOT/name).read_bytes()
def obj(name): return json.loads(raw(name))
def canonical(x): return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',', ':'),allow_nan=False).encode()
def check(name, condition):
    if not condition: raise AssertionError(name)
    checks.append(name)

archive = raw('evidence/EVO896-review-packet-LLMCLI-v0.1.1.zip')
check('old_archive_bound_SHA', digest(archive)=='3c0f1959cfdb6500a43e85be9eeb8e76321abdbfe9e31067aa5d4a76f4042441')
with zipfile.ZipFile(ROOT/'evidence/EVO896-review-packet-LLMCLI-v0.1.1.zip') as z:
    check('old_archive_CRC_and_31_files', z.testzip() is None and len(z.namelist())==31)
    old_bytes = {n:z.read(n) for n in z.namelist()}
    old_manifest=json.loads(old_bytes['EVO896-delivery-manifest-v0.1.1.json'])
    check('old_manifest29_SHA_size',len(old_manifest['files'])==29 and all(
        digest(old_bytes[x['path']])==x['sha256'] and len(old_bytes[x['path']])==x['bytes'] for x in old_manifest['files']))
check('old_reviewer_ruling_SHA', digest(raw('evidence/EVO896-v011-design-ruling-v2.txt'))=='634a9dcc2a78aab7b44d6f3f9b09fcde72be6f5de1e6294918edaeb4add8af8b')
op = json.loads(old_bytes['EVO896-prereg-LLMCLI-v0.1.1.json'])
of = json.loads(old_bytes['EVO896-common-profile-v0.1.1.json'])
p = obj('EVO896-prereg-LLMCLI-v0.1.2.json')
f = obj('EVO896-common-profile-v0.1.2.json')
g = obj('EVO896-gate-map-stage-table-v0.1.2.json')
check('prereg_profile_SHA_and_canonical_bytes',
    canonical(f)==raw('EVO896-common-profile-v0.1.2.json') and digest(canonical(f))==p['common_gate_adaptation']['profile_sha256']==g['profile_sha256'])
check('prompt_schema_only_required_arm_version_rebinding',all(
    raw(n)==old_bytes[n] and raw(n.replace('v0.1.1','v0.1.2'))==old_bytes[n].replace(b'LLMCLI-v0.1.1',b'LLMCLI-v0.1.2')
    for n in ['EVO896-prompt-v0.1.1.txt','EVO896-output-schema-v0.1.1.json']))
check('current_prompt_schema_SHA_and_arm_echo_match',digest(raw(p['prompt']['file']))==p['prompt']['sha256']==f['prompt_sha256'] and
    digest(raw(p['output']['schema_file']))==p['output']['schema_sha256']==f['schema_sha256'] and
    obj(p['output']['schema_file'])['properties']['arm_version']['const']==p['arm_version'] and p['arm_version'].encode() in raw(p['prompt']['file']).splitlines()[0])

def same_except(a,b,excluded):
    return {k:v for k,v in a.items() if k not in excluded}=={k:v for k,v in b.items() if k not in excluded}

allowed_p = {'N_accounting','arm_version','common_gate_adaptation','created_at_utc','design_acceptance',
    'review_and_run_dependencies','revision','runtime_termination','schema','shadow_interface','state','statistical_contract','prompt','output'}
check('prereg_every_unrelated_subtree_unchanged',same_except(op,p,allowed_p))
allowed_f = {'N','V','DSR','additional_post63_evaluation_proposal','approval_questions','arm_version','design_acceptance',
    'falsification','gate_mappings','profile_id','rejection_default','role_registry','runtime_termination','schema',
    'stage_dependencies','status','training_and_label_gate','window','prompt_sha256','schema_sha256'}
check('profile_every_unrelated_subtree_unchanged',same_except(of,f,allowed_f))
check('stability_execution_prices_economics_unchanged',all(op[k]==p[k] for k in [
    'model_binding','input_snapshot','cost_policy','signal_params','portfolio_policy',
    'rebalance_policy','initialization','decision_pipeline','stability','LLM_specific_design_diff','source_bindings','benchmarks']))
check('prompt_and_output_semantics_unchanged',same_except(op['prompt'],p['prompt'],{'file','sha256'}) and
    same_except(op['output'],p['output'],{'schema_file','schema_sha256'}))
check('mechanical_algorithms_models_source_bindings_unchanged',of['roles']==f['roles'])
check('DSR_formula_and_V_max_unchanged',same_except(of['DSR'],f['DSR'],{'role_by_day'}) and same_except(of['V'],f['V'],{'source_reliability'}))
check('QQQ_stop_unavailability_and_horizon_limits_unchanged',same_except(of['falsification'],f['falsification'],{'day63_L_le0_ltU','extension_configuration_frozen'}))
check('statistical_metrics_interval_and_source_order_unchanged',same_except(op['statistical_contract'],p['statistical_contract'],{
    'shadow_falsification','post63_proposal','same_gate_claim','historical_call_boundary','V_source_reliability','DSR_role_by_day'}))
check('interface_only_three_version_bindings_changed',same_except(op['shadow_interface'],p['shadow_interface'],{'arm_version','namespace_x1','namespace_x2'}))
check('all_three_gate_stage_copies_identical',p['common_gate_adaptation']['gate_mappings']==f['gate_mappings']==g['gate_mappings'] and
    p['common_gate_adaptation']['stage_dependencies']==f['stage_dependencies']==g['stage_dependencies'])
check('runtime_N_and_statistical_rules_synchronized',p['N_accounting']==f['N'] and p['runtime_termination']==f['runtime_termination'] and
    p['statistical_contract']['shadow_falsification']==f['falsification'] and
    p['statistical_contract']['DSR_role_by_day']==f['DSR']['role_by_day'] and
    p['statistical_contract']['historical_call_boundary']==f['window']['historical_call_boundary'])
check('reference_registry_old_identity_semantics_preserved',same_except(of['role_registry'],f['role_registry'],{'family_id','reference_freeze_rules'}))
old_gates = {x['gate_id']:x for x in of['gate_mappings']}
check('18_gate_ids_pointers_stages_pass_flags_preserved',len(f['gate_mappings'])==18 and all(
    same_except(old_gates[x['gate_id']],x,{'approval','mapping','proposed_rule'}) for x in f['gate_mappings']))
old_stages = {x['id']:x for x in of['stage_dependencies']}
check('stage_graph_grants_not_expanded_only_cert_dependency_updated',len(f['stage_dependencies'])==12 and all(
    same_except(old_stages[x['id']],x,{'work','depends_on'} if x['id']=='CERTIFICATION' else {'work'}) for x in f['stage_dependencies']) and
    next(x for x in f['stage_dependencies'] if x['id']=='CERTIFICATION')['depends_on']==['T1'])
check('no_runtime_pass_or_sampling_claim',not p['runtime_consumable'] and not p['forward_sampling_authorized'] and not p['certifiable'] and
    not p['common_gate_adaptation']['common_gate_passed'] and not p['design_acceptance']['author_review_received'] and
    all(not x['passed_now'] for x in f['gate_mappings']) and
    [x['id'] for x in f['stage_dependencies'] if x['authorized_now']]==['D0'])

def resolve(d,parts):
    for s in parts: d=d[int(s)] if isinstance(d,list) else d[s]
    return d
diff = obj('EVO896-v011-to-v012-diff.json')
change_counts = {}
for file in diff['files']:
    check('diff_old_new_SHA_'+file['new_file'],digest(old_bytes[file['old_file']])==file['old_sha256'] and digest(raw(file['new_file']))==file['new_sha256'])
    current=json.loads(old_bytes[file['old_file']])
    for c in file['changes']:
        parts=[x.replace('~1','/').replace('~0','~') for x in c['path'].lstrip('/').split('/')]
        parent=resolve(current,parts[:-1]); key=int(parts[-1]) if isinstance(parent,list) else parts[-1]
        if c['op'] in ['replace','remove']:
            assert parent[key]==c['before'],c['path']
        else:
            assert key not in parent,c['path']
        if c['op']=='remove': del parent[key]
        else: parent[key]=copy.deepcopy(c['after'])
    reconstructed=canonical(current) if file['serialization']=='canonical' else (json.dumps(current,sort_keys=file['serialization']!='original_key_order_pretty',ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    check('diff_reconstruct_exact_bytes_'+file['new_file'],reconstructed==raw(file['new_file']))
    change_counts[file['new_file']]=len(file['changes'])

locators=[]
for pointer,key in [('/stability/invalid_output','invalid_output'),('/model_binding/fallback_allowed','fallback_allowed'),('/statistical_contract/shadow_falsification/day63_U_le0','day63_U_le0')]:
    lines=[i for i,s in enumerate(old_bytes['EVO896-prereg-LLMCLI-v0.1.1.json'].decode().splitlines(),1) if '"'+key+'":' in s]
    assert len(lines)==1
    locators.append({'file':'EVO896-prereg-LLMCLI-v0.1.1.json','sha256':digest(old_bytes['EVO896-prereg-LLMCLI-v0.1.1.json']),
        'json_pointer':pointer,'line':lines[0],'value':resolve(op,pointer.lstrip('/').split('/'))})
check('exact_old_clause_locations_and_new_termination_binding', [x['line'] for x in locators]==[1122,850,1207] and
    p['runtime_termination']['clause']=='A3.RT1' and 'R1_meaning' in p['runtime_termination'])
check('frozen_factor_original_bytes_preserved',digest(old_bytes['evidence/upstream/EVO883-prereg-v1.json'])=='3139ab15b8cb53b3c7cdc81816ce9fa4a6ad1862fb836dcde88f1cc31235447f' and
    digest(old_bytes['evidence/upstream/EVO883-executable-conventions-v1.0.1.json'])=='1767b7cf844721468f506e984c303c49e8ff58c395515404187d403661abe97b')
print(json.dumps({'scope':'offline artifact integrity, diff replay and scope preservation only; not business, statistical or real model validation',
    'passed':len(checks),'checks':checks,'json_change_counts':change_counts,'old_clause_locators':locators,
    'not_performed':['model calls','market acquisition','strategy or shadow execution','return or V/DSR computation','authoritative ledger mutation','frozen factor edit']},ensure_ascii=False,sort_keys=True,indent=2))
