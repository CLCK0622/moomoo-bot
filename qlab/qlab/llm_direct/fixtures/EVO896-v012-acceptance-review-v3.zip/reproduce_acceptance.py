"""Reproduce artifact checks in a separate folder; preserve reviewed receipts."""
from pathlib import Path
from hashlib import sha256
import shutil
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
work = root / "reproduced"
work.mkdir(exist_ok=False)
(work / "downloads").mkdir()
(work / "reviewer012").mkdir()
name = "EVO896-review-packet-LLMCLI-v0.1.2.zip"
archive = root / "downloads" / name
assert sha256(archive.read_bytes()).hexdigest() == "ac9565743c1b3c5449d014995df48e5442fda5184a3ba43d53ab28b21f2b780d"
shutil.copyfile(archive, work / "downloads" / name)
for name in ["verify_acceptance.py", "chief-comment-from-CLI.json"]:
    shutil.copyfile(root / "reviewer012" / name, work / "reviewer012" / name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(not name.startswith("/") and ".." not in Path(name).parts for name in z.namelist())
    z.extractall(work / "packet012")
result = subprocess.run([sys.executable, "EVO896-verify-v0.1.2.py"], cwd=work / "packet012",
                        check=True, capture_output=True, text=True)
(work / "author-verification012-rerun.json").write_text(result.stdout)
subprocess.run([sys.executable, str(work / "reviewer012/verify_acceptance.py")], check=True)
