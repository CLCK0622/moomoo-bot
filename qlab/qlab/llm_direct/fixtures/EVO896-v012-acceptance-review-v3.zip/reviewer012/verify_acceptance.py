"""Read-only design verification; no market/model/statistical execution."""
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "packet012"
OUT = ROOT / "reviewer012"


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


checks = []


def check(name, ok):
    assert ok, name
    checks.append({"check": name, "passed": True})


archive = ROOT / "downloads/EVO896-review-packet-LLMCLI-v0.1.2.zip"
check("source_zip_published_sha", digest(archive) == "ac9565743c1b3c5449d014995df48e5442fda5184a3ba43d53ab28b21f2b780d")
with zipfile.ZipFile(archive) as z:
    check("source_zip_crc_and20_files", z.testzip() is None and len(z.namelist()) == 20)
manifest = read(P / "EVO896-delivery-manifest-v0.1.2.json")
check("manifest18_sha_and_bytes", len(manifest["files"]) == 18 and all(
    digest(P / row["path"]) == row["sha256"] and (P / row["path"]).stat().st_size == row["bytes"]
    for row in manifest["files"]))
lines = (P / "EVO896-SHA256SUMS-v0.1.2.txt").read_text().splitlines()
check("checksum19_entries", len(lines) == 19 and all(
    digest(P / line.split("  ", 1)[1]) == line.split("  ", 1)[0] for line in lines))
authority = read(P / "evidence/authority-v012.json")
live = read(OUT / "chief-comment-from-CLI.json")
check("chief_comment_matches_independent_CLI_read", all(authority["ruling"][k] == live[k]
      for k in ["id", "author_id", "author_type", "content", "revision", "created_at"]))
check("chief_identity_and_conditional_delegation", live["id"] == "01a18bb2-6a21-7033-9775-7186ef6526e4"
      and live["author_id"] == "cc562115-7ef6-4b8f-b4b6-a5b7584b1340"
      and "翰林学士核收后即视为 A1–A3 全部获批" in live["content"])
check("old_v011_archive_exact", digest(P / "evidence/EVO896-review-packet-LLMCLI-v0.1.1.zip") ==
      "3c0f1959cfdb6500a43e85be9eeb8e76321abdbfe9e31067aa5d4a76f4042441")
check("old_review_receipt_exact", digest(P / "evidence/EVO896-v011-design-ruling-v2.txt") ==
      "634a9dcc2a78aab7b44d6f3f9b09fcde72be6f5de1e6294918edaeb4add8af8b")
with zipfile.ZipFile(P / "evidence/EVO896-review-packet-LLMCLI-v0.1.1.zip") as z:
    old_bytes = {name: z.read(name) for name in z.namelist()}
pr = read(P / "EVO896-prereg-LLMCLI-v0.1.2.json")
pf = read(P / "EVO896-common-profile-v0.1.2.json")
old_pr = json.loads(old_bytes["EVO896-prereg-LLMCLI-v0.1.1.json"])
old_pf = json.loads(old_bytes["EVO896-common-profile-v0.1.1.json"])
check("canonical_profile_sha_bound", canonical(pf) == (P / "EVO896-common-profile-v0.1.2.json").read_bytes()
      and digest(P / "EVO896-common-profile-v0.1.2.json") == pr["common_gate_adaptation"]["profile_sha256"]
      == "1736b460538b2b18142877e1729ed839ba83a4f99282c2461de07f2711277e8d")
check("prompt_schema_versions_only", all(
    (P / name.replace("v0.1.1", "v0.1.2")).read_bytes() == old_bytes[name].replace(b"LLMCLI-v0.1.1", b"LLMCLI-v0.1.2")
    for name in ["EVO896-prompt-v0.1.1.txt", "EVO896-output-schema-v0.1.1.json"]))
check("core_model_input_stability_execution_unchanged", all(pr[k] == old_pr[k] for k in [
    "model_binding", "input_snapshot", "stability", "decision_pipeline", "signal_params", "cost_policy",
    "portfolio_policy", "rebalance_policy", "initialization", "LLM_specific_design_diff", "benchmarks", "source_bindings"]))
check("mechanical_reference_algorithms_unchanged", old_pf["roles"] == pf["roles"])
check("A1_reference_freeze_and_reliability", pf["role_registry"]["reference_freeze_rules"]["rules_fixed_before_actual_D0"]
      and pf["V"]["source_reliability"]["label"] == "推断·未验证")
check("A2_no_historical_LLM_call_permission", not pf["window"]["historical_call_boundary"]["historical_LLM_calls_preapproved"]
      and pf["window"]["historical_call_boundary"] == pr["statistical_contract"]["historical_call_boundary"])
fals = pr["statistical_contract"]["shadow_falsification"]
check("A3_QQQ_stop_and_crosszero_extension", fals["day63_U_le0"] == "STOP_VERSION"
      and fals["day63_L_le0_ltU"] == "UNVERIFIED_AUTOMATIC_EXTEND_ONCE_TO126_IF_NO_OTHER_STOP_DSR_NOT_A_GATE"
      and fals["max_total_days"] == 126 and not fals["parameter_tuning_during_extension"]
      and fals == pf["falsification"])
check("A3_DSR_roles_and_extension_fixed_configuration", pf["DSR"]["role_by_day"] == {
    "day63": "DIAGNOSTIC_ONLY_NOT_EXTENSION_GATE", "day126": "CERTIFICATION_INPUT_NOT_AUTOMATIC_CERTIFICATION"}
      and fals["extension_configuration_frozen"] == ["prompt_version", "model_snapshot", "parameters", "aggregation_rule"])
rt = pr["runtime_termination"]
check("A3_RT1_sync_and_termination_no_silent_switch", rt == pf["runtime_termination"] and rt["clause"] == "A3.RT1"
      and not rt["silent_model_or_configuration_switch_allowed"] and len(rt["trigger_any"]) == 2
      and "TERMINATE_VERSION" in rt["action"])
n = pr["N_accounting"]
check("N_own_arm_configuration_primary_and_request_sensitivity", n == pf["N"] and n["same_chain_as_factor_arm"]
      and n["arm_tag"] == "EVO896_LLMCLI" and n["configuration_tuple"] == ["prompt_version", "model_snapshot", "parameters", "ruleset"]
      and n["report_rows"] == ["N_config_own_arm_PRIMARY_GATE", "N_generation_requests_own_arm_SENSITIVITY"])
check("N_replica_conditions_and_comparison_remain_separate", len(n["measurement_replicas"]["conditions_all_required"]) == 3
      and n["measurement_replicas"]["N_config_extra"] == 0
      and n["cross_arm_comparison"]["number_of_arms"] == 2
      and n["cross_arm_comparison"]["separate_comparison_registration_required"]
      and not n["cross_arm_comparison"]["comparison_authorized_by_this_revision"])
check("all_A_questions_reference_chief_conditional_authority", len(pf["approval_questions"]) == 3 and all(
    q["approved"] and q["authority_comment"] == live["id"] and "acceptance" in q["condition"]
    for q in pf["approval_questions"]))
diff = read(P / "EVO896-v011-to-v012-diff.json")
delta_counts = {}
for file in diff["files"]:
    state = json.loads(old_bytes[file["old_file"]])
    for change in file["changes"]:
        path = [s.replace("~1", "/").replace("~0", "~") for s in change["path"].split("/")[1:]]
        parent = state
        for part in path[:-1]:
            parent = parent[int(part)] if isinstance(parent, list) else parent[part]
        key = int(path[-1]) if isinstance(parent, list) else path[-1]
        if change["op"] in ["replace", "remove"]:
            assert parent[key] == change["before"], change["path"]
        else:
            assert not isinstance(parent, list) and key not in parent
        if change["op"] == "remove":
            del parent[key]
        else:
            parent[key] = deepcopy(change["after"])
    if file["serialization"] == "canonical":
        rebuilt = canonical(state)
    else:
        rebuilt = (json.dumps(state, ensure_ascii=False, sort_keys=file["serialization"] != "original_key_order_pretty",
                              indent=2, allow_nan=False) + "\n").encode()
    check("exact_diff_reconstruction_" + file["new_file"], rebuilt == (P / file["new_file"]).read_bytes())
    delta_counts[file["new_file"]] = len(file["changes"])
stages = {s["id"]: s for s in pf["stage_dependencies"]}
check("stage_execution_grants_not_created_and_cert_after126", [k for k, s in stages.items() if s["authorized_now"]] == ["D0"]
      and stages["CERTIFICATION"]["depends_on"] == ["T1"]
      and not pr["runtime_consumable"] and not pr["forward_sampling_authorized"] and not pr["certifiable"]
      and not pr["common_gate_adaptation"]["common_gate_passed"])
rerun = read(ROOT / "author-verification012-rerun.json")
check("author32_checks_reproduced_exact_result", rerun["passed"] == 32 and rerun == read(P / "EVO896-verification-v0.1.2.json"))
now = datetime.now(timezone.utc).isoformat()
result = {
    "reviewed_at_utc": now, "checks_passed": len(checks), "checks": checks,
    "scope": "artifact identity, authorization matching and limited design changes only; no business/model/stability/market/return/DSR acceptance",
    "chief_comment": live["id"], "chief_comment_revision": live["revision"],
    "chief_comment_content_sha256": sha256(live["content"].encode()).hexdigest(),
    "json_change_counts": delta_counts,
    "prereg_sha256": digest(P / "EVO896-prereg-LLMCLI-v0.1.2.json"),
    "profile_sha256": digest(P / "EVO896-common-profile-v0.1.2.json"),
    "model_calls": 0, "market_queries": 0, "return_or_DSR_calculations": 0, "authority_ledger_writes": 0,
}
(OUT / "independent-verification-v012.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"checks_passed": len(checks), "json_change_counts": delta_counts}, ensure_ascii=False))
