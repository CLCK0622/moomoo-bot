Offline design/artifact acceptance only. No model or market calls, return/DSR calculations or authority ledger writes.
Run python3 reproduce_acceptance.py in a fresh extracted directory. Checks run under reproduced/; original accepted receipt and hashes are preserved.
